"use strict";
cc._RF.push(module, '967a1oZod1CQYHXqS8EHBnp', 'MapType');
// script/map/base/MapType.ts

Object.defineProperty(exports, "__esModule", { value: true });
var MapType;
(function (MapType) {
    MapType[MapType["angle45"] = 0] = "angle45";
    MapType[MapType["angle90"] = 1] = "angle90";
    MapType[MapType["honeycomb"] = 2] = "honeycomb";
})(MapType = exports.MapType || (exports.MapType = {}));

cc._RF.pop();