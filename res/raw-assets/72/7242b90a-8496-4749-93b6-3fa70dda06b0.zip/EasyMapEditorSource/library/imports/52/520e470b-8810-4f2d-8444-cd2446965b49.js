"use strict";
cc._RF.push(module, '520e4cLiBBPLYREzSRGlltJ', 'Point');
// script/map/road/Point.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Point = /** @class */ (function () {
    function Point(x, y) {
        if (x === void 0) { x = 0; }
        if (y === void 0) { y = 0; }
        this.x = 0;
        this.y = 0;
        this.x = x;
        this.y = y;
    }
    return Point;
}());
exports.default = Point;

cc._RF.pop();