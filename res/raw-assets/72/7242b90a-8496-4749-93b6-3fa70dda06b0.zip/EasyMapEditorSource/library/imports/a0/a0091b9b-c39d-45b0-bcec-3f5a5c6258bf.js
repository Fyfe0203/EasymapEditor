"use strict";
cc._RF.push(module, 'a0091ubw51FsLzsP1pcYli/', 'MapData');
// script/map/base/MapData.ts

Object.defineProperty(exports, "__esModule", { value: true });
var MapType_1 = require("./MapType");
var MapData = /** @class */ (function () {
    function MapData() {
        this.name = "";
        this.bgName = "";
        this.type = MapType_1.MapType.angle45;
        this.mapWidth = 0;
        this.mapHeight = 0;
        this.nodeWidth = 0;
        this.nodeHeight = 0;
        this.roadDataArr = [];
        //public row:number = 0;
        //public col:number = 0;
        this.mapItem = [];
    }
    return MapData;
}());
exports.default = MapData;

cc._RF.pop();