"use strict";
cc._RF.push(module, '2f328tajjBEEabRmXaJoxWn', 'MapLoadModel');
// script/map/base/MapLoadModel.ts

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 地图加载模式
 */
var MapLoadModel;
(function (MapLoadModel) {
    /**
     * 单张地图加载
     */
    MapLoadModel[MapLoadModel["single"] = 0] = "single";
    /**
     * 分切片加载
     */
    MapLoadModel[MapLoadModel["slices"] = 1] = "slices";
})(MapLoadModel = exports.MapLoadModel || (exports.MapLoadModel = {}));

cc._RF.pop();