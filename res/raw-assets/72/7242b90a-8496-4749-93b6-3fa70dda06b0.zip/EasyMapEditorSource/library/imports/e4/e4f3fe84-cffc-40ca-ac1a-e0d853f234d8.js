"use strict";
cc._RF.push(module, 'e4f3f6Ez/xAyqwa4NhT8jTY', 'IRoadSeeker');
// script/map/road/IRoadSeeker.ts

Object.defineProperty(exports, "__esModule", { value: true });

cc._RF.pop();