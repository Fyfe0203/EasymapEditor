"use strict";
cc._RF.push(module, 'a5569a7KTRDiKGvGCqxNAHv', 'RoadNode');
// script/map/road/RoadNode.ts

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 地图路节点
 * @author 落日故人 QQ 583051842
 *
 */
var RoadNode = /** @class */ (function () {
    function RoadNode() {
        this._value = 0; //节点的值
        this._f = 0; //路点的f值
        this._g = 0; //路点的g值	
        this._h = 0; //路点的h值
        this._parent = null; //路点的父节点
    }
    RoadNode.prototype.toString = function () {
        return "路点像素坐标：（" + this._px + "," + this._py + "),  " +
            "路点世界坐标：（" + this._cx + "," + this._cy + "),  " +
            "路点平面直角坐标：（" + this._dx + "," + this._dy + ")";
    };
    Object.defineProperty(RoadNode.prototype, "px", {
        get: function () {
            return this._px;
        },
        set: function (value) {
            this._px = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(RoadNode.prototype, "py", {
        get: function () {
            return this._py;
        },
        set: function (value) {
            this._py = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(RoadNode.prototype, "cx", {
        get: function () {
            return this._cx;
        },
        set: function (value) {
            this._cx = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(RoadNode.prototype, "cy", {
        get: function () {
            return this._cy;
        },
        set: function (value) {
            this._cy = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(RoadNode.prototype, "dx", {
        get: function () {
            return this._dx;
        },
        set: function (value) {
            this._dx = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(RoadNode.prototype, "dy", {
        get: function () {
            return this._dy;
        },
        set: function (value) {
            this._dy = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(RoadNode.prototype, "value", {
        get: function () {
            return this._value;
        },
        set: function (val) {
            this._value = val;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(RoadNode.prototype, "f", {
        get: function () {
            return this._f;
        },
        set: function (value) {
            this._f = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(RoadNode.prototype, "g", {
        get: function () {
            return this._g;
        },
        set: function (value) {
            this._g = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(RoadNode.prototype, "h", {
        get: function () {
            return this._h;
        },
        set: function (value) {
            this._h = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(RoadNode.prototype, "parent", {
        get: function () {
            return this._parent;
        },
        set: function (value) {
            this._parent = value;
        },
        enumerable: true,
        configurable: true
    });
    return RoadNode;
}());
exports.default = RoadNode;

cc._RF.pop();