
export enum MapType 
{
    angle45 = 0,
    angle90 = 1,
    honeycomb = 2,
}
