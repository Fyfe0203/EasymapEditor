(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/Main.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '08578t5Vl9N1ZlW30M5nHYi', 'Main', __filename);
// script/Main.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var SceneMap_1 = require("./SceneMap");
var MapLoadModel_1 = require("./map/base/MapLoadModel");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Main = /** @class */ (function (_super) {
    __extends(Main, _super);
    function Main() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.sceneMap = null;
        return _this;
        // update (dt) {}
    }
    // LIFE-CYCLE CALLBACKS:
    // onLoad () {}
    Main.prototype.start = function () {
        cc.debug.setDisplayStats(false);
        this.sceneMap.node.active = false;
        this.loadSlicesMap();
    };
    /**
     * 加载单张地图
     */
    Main.prototype.loadSingleMap = function () {
        var _this = this;
        var mapName = "mapData";
        cc.loader.loadRes("map/data/" + mapName, cc.JsonAsset, function (error, res) {
            var mapData = res.json;
            cc.loader.loadRes("map/bg/" + mapData.bgName, cc.Texture2D, function (error, tex) {
                _this.sceneMap.node.active = true;
                _this.sceneMap.init(mapData, tex, MapLoadModel_1.MapLoadModel.single);
            });
        });
    };
    /**
     * 加载分切片地图
     */
    Main.prototype.loadSlicesMap = function () {
        var _this = this;
        var mapName = "mapData";
        cc.loader.loadRes("map/data/" + mapName, cc.JsonAsset, function (error, res) {
            var mapData = res.json;
            cc.loader.loadRes("map/bg/" + mapData.bgName + "/miniMap", cc.Texture2D, function (error, tex) {
                _this.sceneMap.node.active = true;
                _this.sceneMap.init(mapData, tex, MapLoadModel_1.MapLoadModel.slices);
            });
        });
    };
    __decorate([
        property(SceneMap_1.default)
    ], Main.prototype, "sceneMap", void 0);
    Main = __decorate([
        ccclass
    ], Main);
    return Main;
}(cc.Component));
exports.default = Main;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Main.js.map
        