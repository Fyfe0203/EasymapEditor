(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/map/base/MapType.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '967a1oZod1CQYHXqS8EHBnp', 'MapType', __filename);
// script/map/base/MapType.ts

Object.defineProperty(exports, "__esModule", { value: true });
var MapType;
(function (MapType) {
    MapType[MapType["angle45"] = 0] = "angle45";
    MapType[MapType["angle90"] = 1] = "angle90";
    MapType[MapType["honeycomb"] = 2] = "honeycomb";
})(MapType = exports.MapType || (exports.MapType = {}));

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=MapType.js.map
        