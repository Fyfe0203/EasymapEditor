(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/map/road/MapRoadUtils.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '38983rww8xCor2DSeawAfiI', 'MapRoadUtils', __filename);
// script/map/road/MapRoadUtils.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Point_1 = require("./Point");
var RoadNode_1 = require("./RoadNode");
var MapType_1 = require("../base/MapType");
/**
 * 地图路点的换算
 * @author 落日故人 QQ 583051842
 *
 */
var MapRoadUtils = /** @class */ (function () {
    function MapRoadUtils() {
    }
    Object.defineProperty(MapRoadUtils, "instance", {
        get: function () {
            if (this._instance == null) {
                this._instance = new MapRoadUtils();
            }
            return this._instance;
        },
        enumerable: true,
        configurable: true
    });
    MapRoadUtils.prototype.updateMapInfo = function (mapWidth, mapHeight, nodeWidth, nodeHeight, mapType) {
        this._mapWidth = mapWidth;
        this._mapHeight = mapHeight;
        this._nodeWidth = nodeWidth;
        this._nodeHeight = nodeHeight;
        this._halfNodeWidth = Math.floor(this._nodeWidth / 2);
        this._halfNodeHeight = Math.floor(this._nodeHeight / 2);
        this._col = Math.ceil(mapWidth / this._nodeWidth);
        this._row = Math.ceil(mapHeight / this._nodeHeight);
        this._mapType = mapType;
        switch (this._mapType) {
            case MapType_1.MapType.angle45:
                this._mapRoad = new MapRoad45Angle(this._row, this._col, this._nodeWidth, this._nodeHeight, this._halfNodeWidth, this._halfNodeHeight);
                break;
            case MapType_1.MapType.angle90:
                this._mapRoad = new MapRoad90Angle(this._row, this._col, this._nodeWidth, this._nodeHeight, this._halfNodeWidth, this._halfNodeHeight);
                break;
            case MapType_1.MapType.honeycomb:
                //this._nodeHeight = (this._nodeWidth / 2) * 1.732;
                this._col = Math.ceil((this._mapWidth - this._nodeWidth / 4) / (this._nodeWidth / 4 * 6)) * 2;
                this._row = Math.ceil((this._mapHeight - this._nodeHeight / 2) / this._nodeHeight);
                this._mapRoad = new MapRoadHoneycomb(this._row, this._col, this._nodeWidth, this._nodeHeight, this._halfNodeWidth, this._halfNodeHeight);
                break;
        }
    };
    /**
     *根据地图平面像素坐标获得路节点
        * @param x
        * @param y
        * @return
        *
        */
    MapRoadUtils.prototype.getNodeByPixel = function (x, y) {
        if (this._mapRoad) {
            return this._mapRoad.getNodeByPixel(x, y);
        }
        return new RoadNode_1.default();
    };
    /**
     *根据路点平面坐标点获得路节点
        * @param px
        * @param py
        * @return
        *
        */
    MapRoadUtils.prototype.getNodeByDerect = function (dx, dy) {
        if (this._mapRoad) {
            return this._mapRoad.getNodeByDerect(dx, dy);
        }
        return new RoadNode_1.default();
    };
    /**
     *根据路点场景世界坐标获得路节点
        * @param wx
        * @param wy
        * @return
        *
        */
    MapRoadUtils.prototype.getNodeByWorldPoint = function (wx, wy) {
        if (this._mapRoad) {
            return this._mapRoad.getNodeByWorldPoint(wx, wy);
        }
        return new RoadNode_1.default();
    };
    /**
     *根据像素坐标得到场景世界坐标
        * @param x
        * @param y
        * @return
        *
        */
    MapRoadUtils.prototype.getWorldPointByPixel = function (x, y) {
        if (this._mapRoad) {
            return this._mapRoad.getWorldPointByPixel(x, y);
        }
        return new Point_1.default();
    };
    /**
     *根据世界坐标获得像素坐标
        * @param cx
        * @param cy
        * @return
        *
        */
    MapRoadUtils.prototype.getPixelByWorldPoint = function (cx, cy) {
        if (this._mapRoad) {
            return this._mapRoad.getPixelByWorldPoint(cx, cy);
        }
        return new Point_1.default();
    };
    /**
     *根据像素坐标获得网格平面坐标
        * @param x
        * @param y
        * @return
        *
        */
    MapRoadUtils.prototype.getDerectByPixel = function (x, y) {
        if (this._mapRoad) {
            return this._mapRoad.getDerectByPixel(x, y);
        }
        return new Point_1.default();
    };
    /**
     *根据世界坐标获得网格平面坐标
        * @param cx
        * @param cy
        * @return
        *
        */
    MapRoadUtils.prototype.getDerectByWorldPoint = function (cx, cy) {
        if (this._mapRoad) {
            return this._mapRoad.getDerectByWorldPoint(cx, cy);
        }
        return new Point_1.default();
    };
    /**
     *根据网格平面坐标获得世界坐标
        * @param dx
        * @param dy
        * @return
        *
        */
    /*	public getWorldPointByDerect(dx:number,dy:number):Point
        {
            var cx:number = (dy + dx) / 2;
            var cy:number = (dy - dx) / 2 + col - 1;
            return new Point(cx,cy);
        }*/
    MapRoadUtils.prototype.getPixelByDerect = function (dx, dy) {
        if (this._mapRoad) {
            return this._mapRoad.getPixelByDerect(dx, dy);
        }
        return new Point_1.default();
    };
    Object.defineProperty(MapRoadUtils.prototype, "mapWidth", {
        get: function () {
            return this._mapWidth;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(MapRoadUtils.prototype, "mapHeight", {
        get: function () {
            return this._mapHeight;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(MapRoadUtils.prototype, "nodeWidth", {
        get: function () {
            return this._nodeWidth;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(MapRoadUtils.prototype, "nodeHeight", {
        get: function () {
            return this._nodeHeight;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(MapRoadUtils.prototype, "row", {
        get: function () {
            return this._row;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(MapRoadUtils.prototype, "col", {
        get: function () {
            return this._col;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(MapRoadUtils.prototype, "halfNodeWidth", {
        get: function () {
            return this._halfNodeWidth;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(MapRoadUtils.prototype, "halfNodeHeight", {
        get: function () {
            return this._halfNodeHeight;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(MapRoadUtils.prototype, "mapType", {
        /**
         *地图类型 0:斜45度等视角地图, 1:90度角平面地图
            */
        get: function () {
            return this._mapType;
        },
        enumerable: true,
        configurable: true
    });
    return MapRoadUtils;
}());
exports.default = MapRoadUtils;
/**
 *45度等视角地图路点处理接口实现
 * @author Administrator
 *
 */
var MapRoad45Angle = /** @class */ (function () {
    function MapRoad45Angle(row, col, nodeWidth, nodeHeight, halfNodeWidth, halfNodeHeight) {
        this._row = row;
        this._col = col;
        this._nodeWidth = nodeWidth;
        this._nodeHeight = nodeHeight;
        this._halfNodeWidth = halfNodeWidth;
        this._halfNodeHeight = halfNodeHeight;
    }
    /**
     *根据地图平面像素坐标获得路节点
     * @param x
     * @param y
     * @return
     *
     */
    MapRoad45Angle.prototype.getNodeByPixel = function (x, y) {
        var wPoint = this.getWorldPointByPixel(x, y);
        var fPoint = this.getPixelByWorldPoint(wPoint.x, wPoint.y);
        var dPoint = this.getDerectByPixel(x, y);
        var node = new RoadNode_1.default();
        node.cx = wPoint.x;
        node.cy = wPoint.y;
        node.px = fPoint.x;
        node.py = fPoint.y;
        node.dx = dPoint.x;
        node.dy = dPoint.y;
        return node;
    };
    /**
     *根据路点平面坐标点获得路节点
     * @param px
     * @param py
     * @return
     *
     */
    MapRoad45Angle.prototype.getNodeByDerect = function (dx, dy) {
        var fPoint = this.getPixelByDerect(dx, dy);
        var wPoint = this.getWorldPointByPixel(fPoint.x, fPoint.y);
        var node = new RoadNode_1.default();
        node.cx = wPoint.x;
        node.cy = wPoint.y;
        node.px = fPoint.x;
        node.py = fPoint.y;
        node.dx = dx;
        node.dy = dy;
        return node;
    };
    /**
     *根据路点场景世界坐标获得路节点
     * @param wx
     * @param wy
     * @return
     *
     */
    MapRoad45Angle.prototype.getNodeByWorldPoint = function (wx, wy) {
        var point = this.getPixelByWorldPoint(wx, wy);
        return this.getNodeByPixel(point.x, point.y);
    };
    /**
     *根据像素坐标得到场景世界坐标
     * @param x
     * @param y
     * @return
     *
     */
    MapRoad45Angle.prototype.getWorldPointByPixel = function (x, y) {
        var cx = Math.ceil(x / this._nodeWidth - 0.5 + y / this._nodeHeight) - 1;
        var cy = (this._col - 1) - Math.ceil(x / this._nodeWidth - 0.5 - y / this._nodeHeight);
        return new Point_1.default(cx, cy);
    };
    /**
     *根据世界坐标获得像素坐标
     * @param cx
     * @param cy
     * @return
     *
     */
    MapRoad45Angle.prototype.getPixelByWorldPoint = function (cx, cy) {
        var x = Math.floor((cx + 1 - (cy - (this._col - 1))) * this._halfNodeWidth);
        var y = Math.floor((cx + 1 + (cy - (this._col - 1))) * this._halfNodeHeight);
        return new Point_1.default(x, y);
    };
    /**
     *根据像素坐标获得网格平面坐标
     * @param x
     * @param y
     * @return
     *
     */
    MapRoad45Angle.prototype.getDerectByPixel = function (x, y) {
        var worldPoint = this.getWorldPointByPixel(x, y);
        var pixelPoint = this.getPixelByWorldPoint(worldPoint.x, worldPoint.y);
        var dx = Math.floor(pixelPoint.x / this._nodeWidth) - (pixelPoint.x % this._nodeWidth == 0 ? 1 : 0);
        var dy = Math.floor(pixelPoint.y / this._halfNodeHeight) - 1;
        return new Point_1.default(dx, dy);
    };
    /**
     *根据世界坐标获得网格平面坐标
     * @param cx
     * @param cy
     * @return
     *
     */
    MapRoad45Angle.prototype.getDerectByWorldPoint = function (cx, cy) {
        var dx = Math.floor((cx - (cy - (this._col - 1))) / 2);
        var dy = cx + (cy - (this._col - 1));
        return new Point_1.default(dx, dy);
    };
    /**
     *根据网格平面坐标获得像素坐标
     * @param dx
     * @param dy
     * @return
     *
     */
    MapRoad45Angle.prototype.getPixelByDerect = function (dx, dy) {
        var x = Math.floor((dx + dy % 2) * this._nodeWidth + (1 - dy % 2) * this._halfNodeWidth);
        var y = Math.floor((dy + 1) * this._halfNodeHeight);
        return new Point_1.default(x, y);
    };
    return MapRoad45Angle;
}());
/**
 *90度平面地图路点处理接口实现
 * @author Administrator
 *
 */
var MapRoad90Angle = /** @class */ (function () {
    function MapRoad90Angle(row, col, nodeWidth, nodeHeight, halfNodeWidth, halfNodeHeight) {
        this._row = row;
        this._col = col;
        this._nodeWidth = nodeWidth;
        this._nodeHeight = nodeHeight;
        this._halfNodeWidth = halfNodeWidth;
        this._halfNodeHeight = halfNodeHeight;
    }
    /**
     *根据地图平面像素坐标获得路节点
     * @param x
     * @param y
     * @return
     *
     */
    MapRoad90Angle.prototype.getNodeByPixel = function (x, y) {
        var wPoint = this.getWorldPointByPixel(x, y);
        var fPoint = this.getPixelByWorldPoint(wPoint.x, wPoint.y);
        var dPoint = this.getDerectByPixel(x, y);
        var node = new RoadNode_1.default();
        node.cx = wPoint.x;
        node.cy = wPoint.y;
        node.px = fPoint.x;
        node.py = fPoint.y;
        node.dx = dPoint.x;
        node.dy = dPoint.y;
        return node;
    };
    /**
     *根据路点平面坐标点获得路节点
     * @param px
     * @param py
     * @return
     *
     */
    MapRoad90Angle.prototype.getNodeByDerect = function (dx, dy) {
        var fPoint = this.getPixelByDerect(dx, dy);
        var wPoint = this.getWorldPointByPixel(fPoint.x, fPoint.y);
        var node = new RoadNode_1.default();
        node.cx = wPoint.x;
        node.cy = wPoint.y;
        node.px = fPoint.x;
        node.py = fPoint.y;
        node.dx = dx;
        node.dy = dy;
        return node;
    };
    /**
     *根据路点场景世界坐标获得路节点
     * @param wx
     * @param wy
     * @return
     *
     */
    MapRoad90Angle.prototype.getNodeByWorldPoint = function (wx, wy) {
        var point = this.getPixelByWorldPoint(wx, wy);
        return this.getNodeByPixel(point.x, point.y);
    };
    /**
     *根据像素坐标得到场景世界坐标
     * @param x
     * @param y
     * @return
     *
     */
    MapRoad90Angle.prototype.getWorldPointByPixel = function (x, y) {
        var cx = Math.floor(x / this._nodeWidth);
        var cy = Math.floor(y / this._nodeHeight);
        return new Point_1.default(cx, cy);
    };
    /**
     *根据世界坐标获得像素坐标
     * @param cx
     * @param cy
     * @return
     *
     */
    MapRoad90Angle.prototype.getPixelByWorldPoint = function (cx, cy) {
        var x = Math.floor((cx + 1) * this._nodeWidth - this._halfNodeWidth);
        var y = Math.floor((cy + 1) * this._nodeHeight - this._halfNodeHeight);
        return new Point_1.default(x, y);
    };
    /**
     *根据像素坐标获得网格平面坐标
     * @param x
     * @param y
     * @return
     *
     */
    MapRoad90Angle.prototype.getDerectByPixel = function (x, y) {
        var dx = Math.floor(x / this._nodeWidth);
        var dy = Math.floor(y / this._nodeHeight);
        return new Point_1.default(dx, dy);
    };
    /**
     *根据世界坐标获得网格平面坐标 90度地图的世界坐标和网格坐标相同
     * @param cx
     * @param cy
     * @return
     *
     */
    MapRoad90Angle.prototype.getDerectByWorldPoint = function (cx, cy) {
        return new Point_1.default(cx, cy);
    };
    /**
     *根据网格平面坐标获得像素坐标
     * @param dx
     * @param dy
     * @return
     *
     */
    MapRoad90Angle.prototype.getPixelByDerect = function (dx, dy) {
        var x = Math.floor((dx + 1) * this._nodeWidth - this._halfNodeWidth);
        var y = Math.floor((dy + 1) * this._nodeHeight - this._halfNodeHeight);
        return new Point_1.default(x, y);
    };
    return MapRoad90Angle;
}());
/**
 *蜂巢式（即正六边形）地图路点处理接口实现
 * @author Administrator
 *
 */
var MapRoadHoneycomb = /** @class */ (function () {
    /**
     *蜂巢式（即正六边形）地图路点处理
     * @param row
     * @param col
     * @param nodeWidth
     * @param nodeHeight
     * @param halfNodeWidth
     * @param halfNodeHeight
     *
     */
    function MapRoadHoneycomb(row, col, nodeWidth, nodeHeight, halfNodeWidth, halfNodeHeight) {
        /**
         * 六边形宽高的tan值，正六边形为1.732
         */
        this._proportion = 1.732;
        this._row = row;
        this._col = col;
        this._nodeWidth = nodeWidth;
        //this._nodeHeight = (this._nodeWidth / 2) * 1.732;
        this._nodeHeight = nodeHeight;
        this._halfNodeWidth = halfNodeWidth;
        this._halfNodeHeight = halfNodeHeight;
        this._nwDiv4 = this._nodeWidth / 4;
        this._radius = this._nwDiv4 * 4;
        this._proportion = this._nodeHeight * 2 / this._nodeWidth;
    }
    /**
     *根据地图平面像素坐标获得路节点
     * @param x
     * @param y
     * @return
     *
     */
    MapRoadHoneycomb.prototype.getNodeByPixel = function (x, y) {
        var wPoint = this.getWorldPointByPixel(x, y);
        var fPoint = this.getPixelByWorldPoint(wPoint.x, wPoint.y);
        //var dPoint:Point = getDerectByPixel(x,y);
        var node = new RoadNode_1.default();
        node.cx = wPoint.x;
        node.cy = wPoint.y;
        node.px = fPoint.x;
        node.py = fPoint.y;
        node.dx = wPoint.x;
        node.dy = wPoint.y;
        return node;
    };
    /**
     *根据路点平面坐标点获得路节点
     * @param px
     * @param py
     * @return
     *
     */
    MapRoadHoneycomb.prototype.getNodeByDerect = function (dx, dy) {
        var fPoint = this.getPixelByDerect(dx, dy);
        //var wPoint:Point = getWorldPointByPixel(fPoint.x,fPoint.y);
        var node = new RoadNode_1.default();
        node.cx = dx;
        node.cy = dy;
        node.px = fPoint.x;
        node.py = fPoint.y;
        node.dx = dx;
        node.dy = dy;
        return node;
    };
    /**
     *根据路点场景世界坐标获得路节点
     * @param wx
     * @param wy
     * @return
     *
     */
    MapRoadHoneycomb.prototype.getNodeByWorldPoint = function (wx, wy) {
        var point = this.getPixelByWorldPoint(wx, wy);
        return this.getNodeByPixel(point.x, point.y);
    };
    /**
     *根据像素坐标得到场景世界坐标
     * @param x
     * @param y
     * @return
     *
     */
    MapRoadHoneycomb.prototype.getWorldPointByPixel = function (x, y) {
        var nwDiv4Index = Math.floor(x / this._nwDiv4); //六边形的外切矩形竖方向均等分成4分，所有的六边形外切矩形连在一起形成一个个4分之一矩形宽的区域，nwDiv4Index就是该区域的索引
        var col = Math.floor(nwDiv4Index / 3); //取得临时六边形横轴的索引,根据不同的情况可能会变
        var row; //六边形纵轴的索引
        var cx;
        var cy;
        if ((nwDiv4Index - 1) % 6 == 0 || (nwDiv4Index - 2) % 6 == 0) {
            row = Math.floor(y / this._nodeHeight);
            cx = col;
            cy = row;
        }
        else if ((nwDiv4Index - 4) % 6 == 0 || (nwDiv4Index - 5) % 6 == 0) {
            if (y < this._nodeHeight / 2) {
                row = -1;
            }
            else {
                row = Math.floor((y - this._nodeHeight / 2) / this._nodeHeight);
            }
            cx = col;
            cy = row;
        }
        else {
            if (col % 2 == 0) {
                //(x - 1,y - 1)  (x - 1,y)
                row = Math.floor(y / this._nodeHeight);
                if (this.testPointInHoneycomb(col, row, x, y)) {
                    cx = col;
                    cy = row;
                }
                else if (this.testPointInHoneycomb(col - 1, row - 1, x, y)) {
                    cx = col - 1;
                    cy = row - 1;
                }
                else {
                    cx = col - 1;
                    cy = row;
                }
            }
            else {
                //(x - 1,y)  (x - 1,y + 1)
                if (y < this._nodeHeight / 2) {
                    row = -1;
                }
                else {
                    row = Math.floor((y - this._nodeHeight / 2) / this._nodeHeight);
                }
                if (this.testPointInHoneycomb(col, row, x, y)) {
                    cx = col;
                    cy = row;
                }
                else if (this.testPointInHoneycomb(col - 1, row, x, y)) {
                    cx = col - 1;
                    cy = row;
                }
                else {
                    cx = col - 1;
                    cy = row + 1;
                }
            }
        }
        return new Point_1.default(cx, cy);
    };
    MapRoadHoneycomb.prototype.testPointInHoneycomb = function (col, row, px, py) {
        var a = this._nwDiv4 * 2;
        var point = this.getPixelByWorldPoint(col, row);
        var absX = Math.abs(px - point.x);
        var absY = Math.abs(py - point.y);
        //return a-absX >= absY/(1.732);
        return a - absX >= absY / this._proportion;
    };
    /**
     *根据世界坐标获得像素坐标
     * @param cx
     * @param cy
     * @return
     *
     */
    MapRoadHoneycomb.prototype.getPixelByWorldPoint = function (cx, cy) {
        var x = Math.floor((2 + 3 * cx) / 4 * this._nodeWidth);
        var y = Math.floor((cy + 1 / 2 * (1 + (cx % 2))) * this._nodeHeight);
        return new Point_1.default(x, y);
    };
    /**
     *根据像素坐标获得网格平面坐标
     * @param x
     * @param y
     * @return
     *
     */
    MapRoadHoneycomb.prototype.getDerectByPixel = function (x, y) {
        return this.getWorldPointByPixel(x, y);
    };
    /**
     *根据世界坐标获得网格平面坐标 90度地图的世界坐标和网格坐标相同
     * @param cx
     * @param cy
     * @return
     *
     */
    MapRoadHoneycomb.prototype.getDerectByWorldPoint = function (cx, cy) {
        return new Point_1.default(cx, cy);
    };
    /**
     *根据网格平面坐标获得像素坐标
     * @param dx
     * @param dy
     * @return
     *
     */
    MapRoadHoneycomb.prototype.getPixelByDerect = function (dx, dy) {
        var x = (2 + 3 * dx) / 4 * this._nodeWidth;
        var y = (dy + 1 / 2 * (1 + (dx % 2))) * this._nodeHeight;
        return new Point_1.default(x, y);
    };
    return MapRoadHoneycomb;
}());

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=MapRoadUtils.js.map
        