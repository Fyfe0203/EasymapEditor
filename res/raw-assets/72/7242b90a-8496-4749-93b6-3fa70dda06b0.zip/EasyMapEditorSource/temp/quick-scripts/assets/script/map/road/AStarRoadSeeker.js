(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/map/road/AStarRoadSeeker.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'a3a193EdkVIWoDgtJ/bBisA', 'AStarRoadSeeker', __filename);
// script/map/road/AStarRoadSeeker.ts

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * A*寻路算法
 * @author 落日故人 QQ 583051842
 *
 */
var AStarRoadSeeker = /** @class */ (function () {
    function AStarRoadSeeker(roadNodes) {
        /**
         * 横向移动一个格子的代价
         */
        this.COST_STRAIGHT = 10;
        /**
         * 斜向移动一个格子的代价
         */
        this.COST_DIAGONAL = 14;
        /**
         *最大搜寻步骤数，超过这个值时表示找不到目标
            */
        this.maxStep = 1000;
        /**
         *用于检索一个节点周围8个点的向量数组
            */
        this._round = [[0, -1], [1, -1], [1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0], [-1, -1]];
        this.handle = -1;
        /**
         * 是否优化路径
         */
        this.optimize = true;
        this._roadNodes = roadNodes;
    }
    /**
     *寻路入口方法
        * @param startNode
        * @param targetNode
        * @return
        *
        */
    AStarRoadSeeker.prototype.seekPath = function (startNode, targetNode) {
        this._startNode = startNode;
        this._currentNode = startNode;
        this._targetNode = targetNode;
        if (!this._startNode || !this._targetNode)
            return [];
        if (this._targetNode.value == 1) {
            console.log("目标不可达到：");
            return [];
        }
        this._openlist = [];
        this._closelist = [];
        var step = 0;
        while (true) {
            if (step > this.maxStep) {
                console.log("没找到目标计算步骤为：", step);
                return [];
            }
            step++;
            this.searchRoundNodes(this._currentNode);
            if (this._openlist.length == 0) {
                console.log("没找到目标计算步骤为：", step);
                return [];
            }
            this._openlist.sort(this.sortNode);
            this._currentNode = this._openlist.shift();
            if (this._currentNode == this._targetNode) {
                console.log("找到目标计算步骤为：", step);
                return this.getPath();
            }
            else {
                this._closelist.push(this._currentNode);
            }
        }
        return [];
    };
    /**
     *寻路入口方法 如果没有寻到目标，则返回离目标最近的路径
    * @param startNode
    * @param targetNode
    * @return
    *
    */
    AStarRoadSeeker.prototype.seekPath2 = function (startNode, targetNode) {
        this._startNode = startNode;
        this._currentNode = startNode;
        this._targetNode = targetNode;
        if (!this._startNode || !this._targetNode)
            return [];
        /*if(this._targetNode.value == 1)
        {
            console.log("目标不可达到：");
            return [];
        }*/
        this._openlist = [];
        this._closelist = [];
        var step = 0;
        var closestNode = null; //距离目标最近的路点
        while (true) {
            if (step > this.maxStep) {
                console.log("没找到目标计算步骤为：", step);
                return this.seekPath(startNode, closestNode);
            }
            step++;
            this.searchRoundNodes(this._currentNode);
            if (this._openlist.length == 0) {
                console.log("没找到目标计算步骤为：", step);
                return this.seekPath(startNode, closestNode);
            }
            this._openlist.sort(this.sortNode);
            this._currentNode = this._openlist.shift();
            if (closestNode == null) {
                closestNode = this._currentNode;
            }
            else {
                if (this._currentNode.h < closestNode.h) {
                    closestNode = this._currentNode;
                }
            }
            if (this._currentNode == this._targetNode) {
                console.log("找到目标计算步骤为：", step);
                return this.getPath();
            }
            else {
                this._closelist.push(this._currentNode);
            }
        }
        return this.seekPath(startNode, closestNode);
    };
    /**
     * 对路节点进行排序
     * @param node1
     * @param node2
     */
    AStarRoadSeeker.prototype.sortNode = function (node1, node2) {
        if (node1.f < node2.f) {
            return -1;
        }
        else if (node1.f > node2.f) {
            return 1;
        }
        return 0;
    };
    /**
     *获得最终寻路到的所有路点
        * @return
        *
        */
    AStarRoadSeeker.prototype.getPath = function () {
        var nodeArr = [];
        var node = this._targetNode;
        while (node != this._startNode) {
            nodeArr.unshift(node);
            node = node.parent;
        }
        nodeArr.unshift(this._startNode);
        if (!this.optimize) {
            return nodeArr;
        }
        //第一阶段优化： 对横，竖，正斜进行优化
        //把多个节点连在一起的，横向或者斜向的一连串点，除两边的点保留
        for (var i = 1; i < nodeArr.length - 1; i++) {
            var preNode = nodeArr[i - 1];
            var midNode = nodeArr[i];
            var nextNode = nodeArr[i + 1];
            var bool1 = midNode.cx == preNode.cx && midNode.cx == nextNode.cx;
            var bool2 = midNode.cy == preNode.cy && midNode.cy == nextNode.cy;
            var bool3 = ((midNode.cx - preNode.cx) / (midNode.cy - preNode.cy)) * ((nextNode.cx - midNode.cx) / (nextNode.cy - midNode.cy)) == 1;
            if (bool1 || bool2 || bool3) {
                nodeArr.splice(i, 1);
                i--;
            }
        }
        //return nodeArr;
        //第二阶段优化：对不在横，竖，正斜的格子进行优化
        for (var i = 0; i < nodeArr.length - 2; i++) {
            var startNode = nodeArr[i];
            var optimizeNode = null;
            //优先从尾部对比，如果能直达就把中间多余的路点删掉
            for (var j = nodeArr.length - 1; j > i + 1; j--) {
                var targetNode = nodeArr[j];
                //在第一阶段优已经优化过横，竖，正斜了，所以再出现是肯定不能优化的，可以忽略
                if (startNode.cx == targetNode.cx || startNode.cy == targetNode.cy || Math.abs(targetNode.cx - startNode.cx) == Math.abs(targetNode.cy - startNode.cy)) {
                    continue;
                }
                if (this.isArriveBetweenTwoNodes(startNode, targetNode)) {
                    optimizeNode = targetNode;
                    break;
                }
            }
            if (optimizeNode) {
                var optimizeLen = j - i - 1;
                nodeArr.splice(i + 1, optimizeLen);
            }
        }
        return nodeArr;
    };
    /**
     * 两点之间是否可到达
     */
    AStarRoadSeeker.prototype.isArriveBetweenTwoNodes = function (startNode, targetNode) {
        if (startNode == targetNode) {
            return false;
        }
        var disX = Math.abs(targetNode.cx - startNode.cx);
        var disY = Math.abs(targetNode.cy - startNode.cy);
        var dirX = 0;
        if (targetNode.cx > startNode.cx) {
            dirX = 1;
        }
        else if (targetNode.cx < startNode.cx) {
            dirX = -1;
        }
        var dirY = 0;
        if (targetNode.cy > startNode.cy) {
            dirY = 1;
        }
        else if (targetNode.cy < startNode.cy) {
            dirY = -1;
        }
        var rx = 0;
        var ry = 0;
        var intNum = 0;
        var decimal = 0;
        if (disX > disY) {
            var rate = disY / disX;
            for (var i = 0; i < disX; i++) {
                ry = startNode.cy + i * dirY * rate;
                intNum = Math.floor(ry);
                decimal = ry % 1;
                var cx1 = startNode.cx + i * dirX;
                var cy1 = decimal <= 0.5 ? intNum : intNum + 1;
                ry = startNode.cy + (i + 1) * dirY * rate;
                intNum = Math.floor(ry);
                decimal = ry % 1;
                var cx2 = startNode.cx + (i + 1) * dirX;
                var cy2 = decimal <= 0.5 ? intNum : intNum + 1;
                var node1 = this._roadNodes[cx1 + "_" + cy1];
                var node2 = this._roadNodes[cx2 + "_" + cy2];
                //cc.log(i + "  :: " + node1.cy," yy ",startNode.cy + i * rate,ry % 1);
                if (!this.isCrossAtAdjacentNodes(node1, node2)) {
                    return false;
                }
            }
        }
        else {
            var rate = disX / disY;
            for (var i = 0; i < disY; i++) {
                rx = i * dirX * rate;
                intNum = dirX > 0 ? Math.floor(startNode.cx + rx) : Math.ceil(startNode.cx + rx);
                decimal = Math.abs(rx % 1);
                var cx1 = decimal <= 0.5 ? intNum : intNum + 1 * dirX;
                var cy1 = startNode.cy + i * dirY;
                rx = (i + 1) * dirX * rate;
                intNum = dirX > 0 ? Math.floor(startNode.cx + rx) : Math.ceil(startNode.cx + rx);
                decimal = Math.abs(rx % 1);
                var cx2 = decimal <= 0.5 ? intNum : intNum + 1 * dirX;
                var cy2 = startNode.cy + (i + 1) * dirY;
                var node1 = this._roadNodes[cx1 + "_" + cy1];
                var node2 = this._roadNodes[cx2 + "_" + cy2];
                if (!this.isCrossAtAdjacentNodes(node1, node2)) {
                    return false;
                }
            }
        }
        return true;
    };
    /**
     * 判断两个相邻的点是否可通过
     * @param node1
     * @param node2
     */
    AStarRoadSeeker.prototype.isCrossAtAdjacentNodes = function (node1, node2) {
        if (node1 == node2) {
            return false;
        }
        //两个点只要有一个点不能通过就不能通过
        if (!this.isPassNode(node1) || !this.isPassNode(node2)) {
            return false;
        }
        var dirX = node2.cx - node1.cx;
        var dirY = node2.cy - node1.cy;
        //如果不是相邻的两个点 则不能通过
        if (Math.abs(dirX) > 1 || Math.abs(dirY) > 1) {
            return false;
        }
        //如果相邻的点是在同一行，或者同一列，则判定为可通过
        if ((node1.cx == node2.cx) || (node1.cy == node2.cy)) {
            return true;
        }
        //只剩对角情况了
        if (this.isPassNode(this._roadNodes[node1.cx + "_" + (node1.cy + dirY)]) &&
            this.isPassNode(this._roadNodes[(node1.cx + dirX) + "_" + node1.cy])) {
            return true;
        }
        return false;
    };
    /**
     * 是否是可通过的点
     * @param node
     */
    AStarRoadSeeker.prototype.isPassNode = function (node) {
        if (!node || node.value == 1) {
            return false;
        }
        return true;
    };
    /**
     *测试寻路步骤
        * @param startNode
        * @param targetNode
        * @return
        *
        */
    AStarRoadSeeker.prototype.testSeekPathStep = function (startNode, targetNode, callback, target, time) {
        var _this = this;
        if (time === void 0) { time = 100; }
        this._startNode = startNode;
        this._currentNode = startNode;
        this._targetNode = targetNode;
        if (this._targetNode.value == 1)
            return;
        this._openlist = [];
        this._closelist = [];
        var step = 0;
        clearInterval(this.handle);
        this.handle = setInterval(function () {
            if (step > _this.maxStep) {
                console.log("没找到目标计算步骤为：", step);
                clearInterval(_this.handle);
                return;
            }
            step++;
            _this.searchRoundNodes(_this._currentNode);
            if (_this._openlist.length == 0) {
                console.log("没找到目标计算步骤为：", step);
                clearInterval(_this.handle);
                return;
            }
            _this._openlist.sort(_this.sortNode);
            _this._currentNode = _this._openlist.shift();
            if (_this._currentNode == _this._targetNode) {
                console.log("找到目标计算步骤为：", step);
                clearInterval(_this.handle);
                callback.apply(target, [_this._startNode, _this._targetNode, _this._currentNode, _this._openlist, _this._closelist, _this.getPath()]);
            }
            else {
                _this._closelist.push(_this._currentNode);
                callback.apply(target, [_this._startNode, _this._targetNode, _this._currentNode, _this._openlist, _this._closelist, null]);
            }
        }, time);
    };
    /**
     *查找一个节点周围可通过的点
        * @param node
        * @return
        *
        */
    AStarRoadSeeker.prototype.searchRoundNodes = function (node) {
        for (var i = 0; i < this._round.length; i++) {
            var cx = node.cx + this._round[i][0];
            var cy = node.cy + this._round[i][1];
            var node2 = this._roadNodes[cx + "_" + cy];
            if (node2 != null && node2 != this._startNode && node2.value != 1 && !this.isInCloseList(node2) && !this.inInCorner(node2)) {
                this.setNodeF(node2);
            }
        }
    };
    /**
     *设置节点的F值
        * @param node
        *
        */
    AStarRoadSeeker.prototype.setNodeF = function (node) {
        var g;
        if (node.cx == this._currentNode.cx || node.cy == this._currentNode.cy) {
            g = this._currentNode.g + this.COST_STRAIGHT;
        }
        else {
            g = this._currentNode.g + this.COST_DIAGONAL;
        }
        if (this.isInOpenList(node)) {
            if (g < node.g) {
                node.g = g;
            }
            else {
                return;
            }
        }
        else {
            node.g = g;
            this._openlist.push(node);
        }
        node.parent = this._currentNode;
        node.h = (Math.abs(this._targetNode.cx - node.cx) + Math.abs(this._targetNode.cy - node.cy)) * this.COST_STRAIGHT;
        node.f = node.g + node.h;
    };
    /**
     *节点是否在开启列表
        * @param node
        * @return
        *
        */
    AStarRoadSeeker.prototype.isInOpenList = function (node) {
        return this._openlist.indexOf(node) != -1 ? true : false;
    };
    /**
     *节点是否在关闭列表
        *
        */
    AStarRoadSeeker.prototype.isInCloseList = function (node) {
        return this._closelist.indexOf(node) != -1 ? true : false;
    };
    /**
     *节点是否在拐角处
        * @return
        *
        */
    AStarRoadSeeker.prototype.inInCorner = function (node) {
        if (node.cx == this._currentNode.cx || node.cy == this._currentNode.cy) {
            return false;
        }
        var node1 = this._roadNodes[this._currentNode.cx + "_" + node.cy];
        var node2 = this._roadNodes[node.cx + "_" + this._currentNode.cy];
        if (this.isPassNode(node1) && this.isPassNode(node2)) {
            return false;
        }
        return true;
    };
    AStarRoadSeeker.prototype.dispose = function () {
        this._roadNodes = null;
        this._round = null;
    };
    return AStarRoadSeeker;
}());
exports.default = AStarRoadSeeker;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=AStarRoadSeeker.js.map
        