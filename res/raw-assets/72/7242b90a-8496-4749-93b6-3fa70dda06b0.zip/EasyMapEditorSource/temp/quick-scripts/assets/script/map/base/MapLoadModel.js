(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/map/base/MapLoadModel.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '2f328tajjBEEabRmXaJoxWn', 'MapLoadModel', __filename);
// script/map/base/MapLoadModel.ts

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 地图加载模式
 */
var MapLoadModel;
(function (MapLoadModel) {
    /**
     * 单张地图加载
     */
    MapLoadModel[MapLoadModel["single"] = 0] = "single";
    /**
     * 分切片加载
     */
    MapLoadModel[MapLoadModel["slices"] = 1] = "slices";
})(MapLoadModel = exports.MapLoadModel || (exports.MapLoadModel = {}));

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=MapLoadModel.js.map
        