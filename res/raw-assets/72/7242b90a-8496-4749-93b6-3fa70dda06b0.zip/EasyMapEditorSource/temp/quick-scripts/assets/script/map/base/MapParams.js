(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/map/base/MapParams.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '6b00e3/60pNy69HrXB4iMm4', 'MapParams', __filename);
// script/map/base/MapParams.ts

Object.defineProperty(exports, "__esModule", { value: true });
var MapType_1 = require("./MapType");
var MapLoadModel_1 = require("./MapLoadModel");
/**
 * 地图参数
 */
var MapParams = /** @class */ (function () {
    function MapParams() {
        /**
         * 地图名称
         */
        this.name = "";
        /**
         * 底图资源名称
         */
        this.bgName = "";
        /**
         * 地图类型
         */
        this.mapType = MapType_1.MapType.angle45;
        /**
         * 地图宽
         */
        this.mapWidth = 750;
        /**
         * 地图高
         */
        this.mapHeight = 1600;
        /**
         * 地图单元格宽
         */
        this.ceilWidth = 75;
        /**
         * 地图单元格高
         */
        this.ceilHeight = 75;
        /**
         * 地图视野宽
         */
        this.viewWidth = 750;
        /**
         * 地图视野高
         */
        this.viewHeight = 1334;
        /**
         * 地图切片宽
         */
        this.sliceWidth = 256;
        /**
         * 地图切片高
         */
        this.sliceHeight = 256;
        /**
         * 底图加载模式，是单张还是切片加载
         */
        this.mapLoadModel = MapLoadModel_1.MapLoadModel.single;
        /**
         * 地图底图
         */
        this.bgTex = null;
    }
    return MapParams;
}());
exports.default = MapParams;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=MapParams.js.map
        