(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/map/layer/MapLayer.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '753fbcKY45E1Lc2+Glt9EhY', 'MapLayer', __filename);
// script/map/layer/MapLayer.ts

// Learn TypeScript:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/typescript.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/typescript.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html
Object.defineProperty(exports, "__esModule", { value: true });
var MapLoadModel_1 = require("../base/MapLoadModel");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
/**
 * 地图层
 * @author 落日故人 QQ 583051842
 *
 */
var MapLayer = /** @class */ (function (_super) {
    __extends(MapLayer, _super);
    function MapLayer() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        /**
         *切割小图片集
         */
        _this._sliceImgDic = {};
        _this._mapParams = null;
        _this.bgImg = null;
        return _this;
    }
    MapLayer.prototype.init = function (mapParams) {
        this._mapParams = mapParams;
        if (!this.bgImg) {
            var bgNode = new cc.Node();
            this.node.addChild(bgNode);
            bgNode.anchorX = 0;
            bgNode.anchorY = 0;
            this.bgImg = bgNode.addComponent(cc.Sprite);
        }
        this.bgImg.spriteFrame = new cc.SpriteFrame(this._mapParams.bgTex);
        //如果是马赛克小地图，则需要把小地图缩放成原始地图一样大小
        if (mapParams.mapLoadModel == MapLoadModel_1.MapLoadModel.slices) {
            this.bgImg.node.width = mapParams.mapWidth;
            this.bgImg.node.height = mapParams.mapHeight;
        }
        this.node.width = this.width;
        this.node.height = this.height;
    };
    MapLayer.prototype.load = function (url) {
        //ResourceLoader.getInstance().load(url,onLoadComplete);	
    };
    MapLayer.prototype.onLoadComplete = function () {
        //var bitmapData:BitmapData = (content as Bitmap).bitmapData;
        //_bgImg.bitmapData = bitmapData;
        //this.dispatchEvent(new MsgEvent(MsgEvent.INIT_COMP,{width:bitmapData.width,height:bitmapData.height}));
    };
    /**
     * 根据视图区域加载小地图
     * @param px 滚动视图左上角的x坐标
     * @param py 滚动视图左上角的y坐标
     *
     */
    MapLayer.prototype.loadSliceImage = function (px, py) {
        var iy1 = Math.floor(py / this._mapParams.sliceHeight);
        var iy2 = Math.floor((py + this._mapParams.viewHeight) / this._mapParams.sliceHeight);
        var jx1 = Math.floor(px / this._mapParams.sliceWidth);
        var jx2 = Math.floor((px + this._mapParams.viewWidth) / this._mapParams.sliceWidth);
        var key;
        for (var i = iy1; i <= iy2; i++) {
            var _loop_1 = function () {
                key = (i + 1) + "_" + (j + 1); // 图片的索引是从1开始的，所以要加1
                if (!this_1._sliceImgDic[key]) {
                    var bitmap_1 = this_1.getSliceSprite(key);
                    this_1._sliceImgDic[key] = bitmap_1;
                    this_1.node.addChild(bitmap_1.node);
                    bitmap_1.node.x = j * this_1._mapParams.sliceWidth;
                    bitmap_1.node.y = i * this_1._mapParams.sliceHeight;
                    /*var root = "远程资源地址"; //填写你的远程资源地址

                    cc.loader.load(root + "map_bg/slices/" + key + ".jpg",(err:Error,tex:cc.Texture2D)=>
                    {
                        if(err)
                        {
                            cc.log("加载远程资源失败",err);
                        }else
                        {
                            bitmap.spriteFrame = new cc.SpriteFrame(tex);
                        }
                    });*/
                    cc.loader.loadRes("map/bg/" + this_1._mapParams.bgName + "/slices/" + key, cc.Texture2D, function (error, tex) {
                        bitmap_1.spriteFrame = new cc.SpriteFrame(tex);
                    });
                }
            };
            var this_1 = this;
            for (var j = jx1; j <= jx2; j++) {
                _loop_1();
            }
        }
        //C:\Users\ASUS\AppData\Local\Google\Chrome\Application\chrome.exe
    };
    MapLayer.prototype.getSliceSprite = function (name) {
        var node = new cc.Node(name);
        var sprite = node.addComponent(cc.Sprite);
        node.anchorX = 0;
        node.anchorY = 0;
        return sprite;
    };
    MapLayer.prototype.clear = function () {
        this.bgImg.spriteFrame = null;
        for (var key in this._sliceImgDic) {
            var bitmap = this._sliceImgDic[key];
            bitmap && bitmap.node.destroy();
            this._sliceImgDic[key] = null;
            delete this._sliceImgDic[key];
        }
    };
    Object.defineProperty(MapLayer.prototype, "bgImage", {
        get: function () {
            return this.bgImg;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(MapLayer.prototype, "width", {
        get: function () {
            if (this.bgImg) {
                return this.bgImg.node.width;
            }
            return this._mapParams.viewWidth;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(MapLayer.prototype, "height", {
        get: function () {
            if (this.bgImg) {
                return this.bgImg.node.height;
            }
            return this._mapParams.viewHeight;
        },
        enumerable: true,
        configurable: true
    });
    __decorate([
        property(cc.Sprite)
    ], MapLayer.prototype, "bgImg", void 0);
    MapLayer = __decorate([
        ccclass
    ], MapLayer);
    return MapLayer;
}(cc.Component));
exports.default = MapLayer;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=MapLayer.js.map
        