(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/map/base/MapData.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'a0091ubw51FsLzsP1pcYli/', 'MapData', __filename);
// script/map/base/MapData.ts

Object.defineProperty(exports, "__esModule", { value: true });
var MapType_1 = require("./MapType");
var MapData = /** @class */ (function () {
    function MapData() {
        this.name = "";
        this.bgName = "";
        this.type = MapType_1.MapType.angle45;
        this.mapWidth = 0;
        this.mapHeight = 0;
        this.nodeWidth = 0;
        this.nodeHeight = 0;
        this.roadDataArr = [];
        //public row:number = 0;
        //public col:number = 0;
        this.mapItem = [];
    }
    return MapData;
}());
exports.default = MapData;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=MapData.js.map
        